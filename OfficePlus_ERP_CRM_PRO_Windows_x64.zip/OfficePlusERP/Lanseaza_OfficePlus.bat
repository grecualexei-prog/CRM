@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
title OfficePlus ERP + CRM REAL
cd /d "%~dp0"

where node >nul 2>&1
if %errorlevel%==0 (
  start "OfficePlus API REAL" cmd /c "node server\server.js"
  timeout /t 2 /nobreak >nul
  set "URL=http://127.0.0.1:3847/index.html"
) else (
  echo Node.js nu este instalat — mod local (localStorage real).
  set "URL=%~dp0index.html"
)

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%URL%" --user-data-dir="%TEMP%\OfficePlusERP_Profile"
  exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%URL%" --user-data-dir="%TEMP%\OfficePlusERP_Profile"
  exit /b 0
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%URL%" --user-data-dir="%TEMP%\OfficePlusERP_Profile"
  exit /b 0
)
start "" "%URL%"
