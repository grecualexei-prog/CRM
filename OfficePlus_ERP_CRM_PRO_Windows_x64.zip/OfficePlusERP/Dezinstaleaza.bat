@echo off
chcp 65001 >nul 2>&1
title Dezinstalare OfficePlus ERP
color 0C
echo.
echo  Se dezinstaleaza OfficePlus ERP + CRM PRO...
echo.
set "DEST=%LOCALAPPDATA%\OfficePlusERP"
if exist "%DEST%" (
  rmdir /S /Q "%DEST%" 2>nul
  echo  Stergere folder: OK
) else (
  echo  Folderul nu exista (deja sters).
)

del "%USERPROFILE%\Desktop\OfficePlus ERP.lnk" 2>nul
del "%USERPROFILE%\OneDrive\Desktop\OfficePlus ERP.lnk" 2>nul
del "%USERPROFILE%\OneDrive\Desktopul\OfficePlus ERP.lnk" 2>nul
rmdir /S /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\OfficePlus" 2>nul

echo.
echo  Dezinstalare finalizata.
echo.
pause
