/**
 * OfficePlus ERP — API REAL + autentificare utilizatori
 * node server/server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const https = require('https');
const { URL } = require('url');

const PORT = process.env.PORT || 3847;
const ROOT = path.join(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'officeplus.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function hashPassword(password, salt) {
  const s = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), s, 32).toString('hex');
  return { salt: s, hash };
}
function verifyPassword(password, salt, hash) {
  try {
    const h = crypto.scryptSync(String(password), salt, 32).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(h, 'hex'), Buffer.from(hash, 'hex'));
  } catch (e) {
    return false;
  }
}

function defaultDb() {
  const admin = hashPassword('admin123');
  const sales = hashPassword('sales123');
  return {
    meta: { version: 2, company: 'GRECU OFFICE GROUP SRL', currency: 'MDL', updated: new Date().toISOString() },
    products: [
      { id: 1, art: 'OP-A4-80', name: 'Hârtie A4 80g 500 coli', ean: '4840000000012', grup: 'Hârtie', stoc: 420, pret: 67, online: 69, status: 'Activ', depozit: 'Bălți Central' },
      { id: 2, art: 'OP-TON-80', name: 'Toner HP CF280A', ean: '4840000000029', grup: 'Toner', stoc: 48, pret: 185, online: 199, status: 'Activ', depozit: 'Bălți Central' },
      { id: 3, art: 'OP-PIX-01', name: 'Pix albastru 1.0mm', ean: '4840000000036', grup: 'Rechizite', stoc: 1200, pret: 2.5, online: 3, status: 'Activ', depozit: 'Bălți Central' }
    ],
    clients: [
      { id: 1, name: 'SC Exemplu SRL', idno: '1000000012345', tel: '060000000', resp: 'Alex', sold: 12400, status: 'Activ' },
      { id: 2, name: 'Compania Nord SRL', idno: '1000000067890', tel: '069000000', resp: 'Maria', sold: 38700, status: 'Restanță' },
      { id: 3, name: 'ABC SRL', idno: '1000000022222', tel: '067222222', resp: 'Ion', sold: 8200, status: 'Activ' }
    ],
    invoices: [
      { id: 1, nr: 'OP-000874', client: 'ABC SRL', total: 14500, scad: '05.10.2026', ef: 'Validată', status: 'Neachitată' },
      { id: 2, nr: 'OP-000875', client: 'Nord Office SRL', total: 35400, scad: '08.10.2026', ef: 'Validată', status: 'Achitată' }
    ],
    orders: [
      { id: 1, nr: 'OP-2026-00871', client: 'Compania Nord SRL', total: 18760, liv: '29.09', plat: 'Transfer', status: 'În procesare' }
    ],
    employees: [
      { id: 1, name: 'Alex Moraru', dept: 'Vânzări', role: 'Manager vânzări', tel: '069111001', email: 'alex@officeplus.md', comm: 5, salary: 18500, hire: '2022-03-01', status: 'Activ' },
      { id: 2, name: 'Maria Cojocaru', dept: 'Vânzări', role: 'Agent vânzări', tel: '069111002', email: 'maria@officeplus.md', comm: 4, salary: 12000, hire: '2023-01-15', status: 'Activ' },
      { id: 3, name: 'Ion Rusu', dept: 'Logistică', role: 'Șef depozit', tel: '069111003', email: 'ion@officeplus.md', comm: 0, salary: 14000, hire: '2021-06-10', status: 'Activ' }
    ],
    users: [
      { id: 1, name: 'admin', role: 'Administrator', modules: 'Toate', tfa: 'Activ', status: 'Activ', salt: admin.salt, passwordHash: admin.hash },
      { id: 2, name: 'sales01', role: 'Vânzări', modules: 'CRM, Vânzări, Stoc', tfa: 'Inactiv', status: 'Activ', salt: sales.salt, passwordHash: sales.hash }
    ],
    movements: [],
    scans: [],
    settings: { comp: 'GRECU OFFICE GROUP SRL', cur: 'MDL', serie: 'OP', lang: 'Română', tva: 'Fără TVA', date: 'DD.MM.YYYY', wh: 'Bălți Central', cashMin: 50000, googleApi: { googleClientId: '', googleClientSecret: '' } },
    integrations: {},
    warehouse: 'Bălți Central',
    counters: { invoice: 876, order: 871, product: 100 }
  };
}

function loadDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const d = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      // migrate users without password
      if (Array.isArray(d.users)) {
        d.users.forEach(u => {
          if (!u.passwordHash || !u.salt) {
            const def = u.name === 'admin' ? 'admin123' : (u.name === 'sales01' ? 'sales123' : 'user123');
            const h = hashPassword(def);
            u.salt = h.salt;
            u.passwordHash = h.hash;
          }
        });
      }
      return d;
    }
  } catch (e) { console.error(e.message); }
  const db = defaultDb();
  saveDb(db);
  return db;
}
function saveDb(db) {
  db.meta = db.meta || {};
  db.meta.updated = new Date().toISOString();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
}

let db = loadDb();
saveDb(db); // persist migrated passwords

const COLLECTIONS = ['products', 'clients', 'invoices', 'orders', 'employees', 'users', 'movements'];
const sessions = new Map(); // token -> { userId, name, role, modules, exp }

// ---- Document scan (VueScan + folder scanate) ----
const SCAN_DIR = path.join(ROOT, 'scanate');
if (!fs.existsSync(SCAN_DIR)) fs.mkdirSync(SCAN_DIR, { recursive: true });

function findVueScan() {
  const candidates = [
    process.env.VUESCAN_PATH,
    'C:\\\\Program Files\\\\VueScan\\\\vuescan.exe',
    'C:\\\\Program Files (x86)\\\\VueScan\\\\vuescan.exe',
    'C:\\\\Program Files\\\\VueScan\\\\vuescan64.exe',
    'C:\\\\VueScan\\\\vuescan.exe',
    path.join(process.env.ProgramFiles || 'C:\\\\Program Files', 'VueScan', 'vuescan.exe'),
    path.join(process.env['ProgramFiles(x86)'] || 'C:\\\\Program Files (x86)', 'VueScan', 'vuescan.exe')
  ].filter(Boolean);
  for (const p of candidates) {
    try { if (fs.existsSync(p)) return p; } catch (e) {}
  }
  return null;
}


function safeFolderName(name) {
  return String(name || 'Necunoscut')
    .replace(/[<>:"/\\\\|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'Necunoscut';
}

function detectDocType(filename, note) {
  const t = (filename + ' ' + (note || '')).toLowerCase();
  if (/contract|acord|act\s*adi/.test(t)) return '01_Contracte';
  if (/\bci\b|buletin|pasaport|identit/.test(t)) return '02_Acte_identitate';
  if (/factura|factură|invoice|proform/.test(t)) return '03_Facturi';
  if (/extras|banca|bank|plata|plată/.test(t)) return '04_Extrase_banca';
  if (/aviz|livrare|transport|cmr/.test(t)) return '05_Avize_livrare';
  if (/oferta|ofertă|deviz/.test(t)) return '06_Oferte';
  if (/proces.?verbal|pv\b/.test(t)) return '07_Procese_verbale';
  if (/email|corespond/.test(t)) return '08_Corespondenta';
  return '09_Altele';
}

function autosortScans() {
  const report = { moved: [], skipped: [], errors: [], folders: [] };
  if (!fs.existsSync(SCAN_DIR)) fs.mkdirSync(SCAN_DIR, { recursive: true });

  // Build file -> client map from db.scans
  const linkMap = {};
  (db.scans || []).forEach(l => {
    if (l.file) linkMap[l.file] = { client: l.client || 'Necunoscut', note: l.note || '' };
  });
  // pending jobs
  (db.scanJobs || []).forEach(j => {
    if (j.client && j.status === 'scanning') {
      /* used for newest unlinked files */
    }
  });

  const files = fs.readdirSync(SCAN_DIR).filter(f => {
    const fp = path.join(SCAN_DIR, f);
    try {
      return fs.statSync(fp).isFile() && /\.(pdf|png|jpg|jpeg|tif|tiff|bmp)$/i.test(f);
    } catch (e) { return false; }
  });

  // newest job client for files not yet linked
  const lastJob = (db.scanJobs || []).find(j => j.client);
  const defaultClient = lastJob ? lastJob.client : 'Necunoscut';

  files.forEach(f => {
    try {
      const src = path.join(SCAN_DIR, f);
      const st = fs.statSync(src);
      const link = linkMap[f];
      const client = safeFolderName(link ? link.client : defaultClient);
      const note = link ? link.note : '';
      const docType = detectDocType(f, note);
      const d = new Date(st.mtime);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const monthFolder = yyyy + '-' + mm;

      // scanate / Client / YYYY-MM / Tip /
      const destDir = path.join(SCAN_DIR, client, monthFolder, docType);
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
        report.folders.push(path.relative(SCAN_DIR, destDir));
      }
      let destName = f;
      let dest = path.join(destDir, destName);
      let n = 1;
      while (fs.existsSync(dest)) {
        const ext = path.extname(f);
        const base = path.basename(f, ext);
        destName = base + '_' + n + ext;
        dest = path.join(destDir, destName);
        n++;
      }
      fs.renameSync(src, dest);
      const rel = path.join(client, monthFolder, docType, destName).replace(/\\\\/g, '/');
      report.moved.push({ from: f, to: rel, client, docType, month: monthFolder });

      // update links paths
      (db.scans || []).forEach(l => {
        if (l.file === f) {
          l.file = rel;
          l.sorted = true;
        }
      });
    } catch (e) {
      report.errors.push({ file: f, error: e.message });
    }
  });

  saveDb(db);
  return report;
}

function listScansTree() {
  const result = [];
  function walk(dir, rel) {
    let entries = [];
    try { entries = fs.readdirSync(dir); } catch (e) { return; }
    entries.forEach(name => {
      if (name === 'CITESTE.txt') return;
      const fp = path.join(dir, name);
      const r = rel ? rel + '/' + name : name;
      try {
        const st = fs.statSync(fp);
        if (st.isDirectory()) {
          result.push({ type: 'dir', name: r, path: r });
          walk(fp, r);
        } else if (/\.(pdf|png|jpg|jpeg|tif|tiff|bmp)$/i.test(name)) {
          result.push({
            type: 'file',
            name: name,
            path: r,
            size: st.size,
            mtime: st.mtime.toISOString()
          });
        }
      } catch (e) {}
    });
  }
  walk(SCAN_DIR, '');
  return result;
}


function listScans() {
  try {
    return fs.readdirSync(SCAN_DIR)
      .filter(f => /\.(pdf|png|jpg|jpeg|tif|tiff|bmp)$/i.test(f))
      .map(f => {
        const fp = path.join(SCAN_DIR, f);
        const st = fs.statSync(fp);
        return { name: f, size: st.size, mtime: st.mtime.toISOString(), path: 'scanate/' + f };
      })
      .sort((a, b) => new Date(b.mtime) - new Date(a.mtime));
  } catch (e) {
    return [];
  }
}


const loginAttempts = new Map(); // ip -> { n, until }
const auditLog = []; // last 200 events
const entityHistory = []; // last 300 entity changes
function pushHistory(entity, id, action, user, detail) {
  entityHistory.unshift({ t: new Date().toISOString(), entity, id, action, user: user || 'system', detail: detail || {} });
  if (entityHistory.length > 300) entityHistory.length = 300;
}


function clientIp(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'local';
}
function audit(event, detail) {
  auditLog.unshift({ t: new Date().toISOString(), event, detail });
  if (auditLog.length > 200) auditLog.length = 200;
}
function checkLoginRate(ip) {
  const now = Date.now();
  let a = loginAttempts.get(ip);
  if (!a) return true;
  if (a.until && now < a.until) return false;
  if (a.until && now >= a.until) { loginAttempts.delete(ip); return true; }
  return true;
}
function recordLoginFail(ip) {
  const now = Date.now();
  let a = loginAttempts.get(ip) || { n: 0, until: 0 };
  a.n += 1;
  if (a.n >= 5) { a.until = now + 5 * 60 * 1000; a.n = 0; } // lock 5 min after 5 fails
  loginAttempts.set(ip, a);
}
function recordLoginOk(ip) { loginAttempts.delete(ip); }


// ---- Google API connect state ----
const googleConnectPending = new Map(); // state -> { provider, exp }


// ---- Google Drive integration ----

// ---- Google Calendar ----
function getGCalConfig() {
  const o = (db.settings && (db.settings.googleApi || db.settings.oauth)) || {}; // legacy key support
  const g = (db.integrations && db.integrations.gcal) || {};
  return {
    clientId: o.googleClientId || process.env.GOOGLE_CLIENT_ID || '',
    clientSecret: o.googleClientSecret || process.env.GOOGLE_CLIENT_SECRET || '',
    refreshToken: g.refreshToken || '',
    accessToken: g.accessToken || '',
    tokenExpiry: g.tokenExpiry || 0,
    calendarId: g.calendarId || 'primary'
  };
}
function saveGCalTokens(partial) {
  db.integrations = db.integrations || {};
  db.integrations.gcal = { ...(db.integrations.gcal || {}), ...partial };
  saveDb(db);
}
async function refreshGCalAccessToken() {
  const cfg = getGCalConfig();
  if (!cfg.refreshToken || !cfg.clientId || !cfg.clientSecret) return null;
  const res = await httpPostForm('https://oauth2.googleapis.com/token', {
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    refresh_token: cfg.refreshToken,
    grant_type: 'refresh_token'
  });
  if (!res.json || !res.json.access_token) return null;
  const exp = Date.now() + ((res.json.expires_in || 3600) - 60) * 1000;
  saveGCalTokens({ accessToken: res.json.access_token, tokenExpiry: exp });
  return res.json.access_token;
}
async function getValidGCalToken() {
  const cfg = getGCalConfig();
  if (cfg.accessToken && cfg.tokenExpiry > Date.now()) return cfg.accessToken;
  return await refreshGCalAccessToken();
}



// ---- MAIB Business (rulaj bancar) + SFS e-Factura ----

function getMaibConfig() {
  const m = (db.integrations && db.integrations.maib) || {};
  return {
    enabled: !!m.enabled,
    // Berlin Group XS2A (Open Banking) — base path configurable
    baseUrl: (m.baseUrl || 'https://api.maibmerchants.md/v1').replace(/\/$/, ''),
    tokenUrl: m.tokenUrl || 'https://api.maibmerchants.md/v1/generate-token',
    // Alternative: e-comm style credentials (Project ID / Secret) if bank issues them for AIS
    projectId: m.projectId || m.clientId || '',
    projectSecret: m.projectSecret || m.clientSecret || '',
    clientId: m.clientId || m.projectId || '',
    clientSecret: m.clientSecret || m.projectSecret || '',
    iban: m.iban || '',
    accountId: m.accountId || '', // resourceId from GET /accounts
    accessToken: m.accessToken || '',
    refreshToken: m.refreshToken || '',
    consentId: m.consentId || '',
    tokenExpiry: m.tokenExpiry || 0,
    mode: m.mode || 'demo', // demo | live
    psuIp: m.psuIp || '127.0.0.1'
  };
}
function saveMaibConfig(partial) {
  db.integrations = db.integrations || {};
  db.integrations.maib = { ...(db.integrations.maib || {}), ...partial };
  saveDb(db);
}

function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

/** HTTPS JSON request helper for MAIB / Berlin Group */
function maibHttp(method, urlStr, headers, bodyObj) {
  return new Promise((resolve, reject) => {
    try {
      const u = new URL(urlStr);
      const body = bodyObj != null ? JSON.stringify(bodyObj) : null;
      const hdrs = Object.assign({
        'Accept': 'application/json',
        'X-Request-ID': uuidv4()
      }, headers || {});
      if (body) {
        hdrs['Content-Type'] = 'application/json';
        hdrs['Content-Length'] = Buffer.byteLength(body);
      }
      const lib = u.protocol === 'http:' ? require('http') : https;
      const req = lib.request({
        hostname: u.hostname,
        port: u.port || (u.protocol === 'https:' ? 443 : 80),
        path: u.pathname + u.search,
        method,
        headers: hdrs,
        timeout: 20000
      }, res => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(text); } catch (e) {}
          resolve({ status: res.statusCode, headers: res.headers, json, text });
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('MAIB timeout')); });
      if (body) req.write(body);
      req.end();
    } catch (e) { reject(e); }
  });
}

/**
 * Obtain access token — supports:
 * 1) maib merchants style: POST {tokenUrl}/generate-token  { projectId, projectSecret }
 * 2) Direct bearer already stored in config
 */
async function maibObtainToken() {
  const cfg = getMaibConfig();
  if (cfg.accessToken && cfg.tokenExpiry > Date.now()) return cfg.accessToken;
  if (!cfg.projectId || !cfg.projectSecret) {
    if (cfg.accessToken) return cfg.accessToken;
    return null;
  }
  // Try maibmerchants generate-token (e-comm pattern; bank may expose similar for AIS)
  // Official maib e-comm / merchants token endpoint
  const candidates = [
    'https://api.maibmerchants.md/v1/generate-token',
    'https://sandbox.maibmerchants.md/v1/generate-token',
    cfg.tokenUrl || '',
    cfg.baseUrl.replace(/\/xs2a\/v1$/, '') + '/v1/generate-token',
    cfg.baseUrl + '/generate-token'
  ].filter(Boolean);
  let lastErr = null;
  for (const url of candidates) {
    try {
      const res = await maibHttp('POST', url, {
        'Content-Type': 'application/json'
      }, {
        projectId: cfg.projectId,
        projectSecret: cfg.projectSecret
      });
      // maib response: { result: { accessToken, expiresIn, refreshToken } } or flat
      const root = res.json || {};
      const result = root.result || root.data || root;
      const tok = result.accessToken || result.access_token || root.accessToken || root.access_token;
      const expSec = result.expiresIn || result.expires_in || root.expiresIn || root.expires_in || 3600;
      const refresh = result.refreshToken || result.refresh_token || root.refreshToken || cfg.refreshToken;
      if (tok) {
        saveMaibConfig({
          accessToken: tok,
          refreshToken: refresh || cfg.refreshToken,
          tokenExpiry: Date.now() + (Number(expSec) - 60) * 1000
        });
        return tok;
      }
      lastErr = res.text || ('HTTP ' + res.status);
    } catch (e) {
      lastErr = e.message;
    }
  }
  throw new Error('Token MAIB eșuat: ' + (lastErr || 'fără răspuns'));
}

/**
 * Berlin Group AIS — list accounts
 * GET /v1/accounts
 * Headers: Authorization, Consent-ID, X-Request-ID
 */
async function maibFetchAccounts(token, consentId) {
  const cfg = getMaibConfig();
  const url = cfg.baseUrl + '/accounts';
  const res = await maibHttp('GET', url, {
    Authorization: 'Bearer ' + token,
    'Consent-ID': consentId || cfg.consentId || ''
  });
  if (res.status >= 400) throw new Error('GET accounts: ' + (res.text || res.status));
  return (res.json && (res.json.accounts || res.json)) || [];
}

/**
 * Berlin Group AIS — transactions
 * GET /v1/accounts/{account-id}/transactions?bookingStatus=booked&dateFrom=...
 */
async function maibFetchTransactions(token, accountId, consentId, dateFrom, dateTo) {
  const cfg = getMaibConfig();
  const from = dateFrom || new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
  const to = dateTo || new Date().toISOString().slice(0, 10);
  let path = cfg.baseUrl + '/accounts/' + encodeURIComponent(accountId) +
    '/transactions?bookingStatus=booked&dateFrom=' + from + '&dateTo=' + to;
  const res = await maibHttp('GET', path, {
    Authorization: 'Bearer ' + token,
    'Consent-ID': consentId || cfg.consentId || '',
    'PSU-IP-Address': cfg.psuIp
  });
  if (res.status >= 400) throw new Error('GET transactions: ' + (res.text || res.status));
  return res.json || {};
}

/**
 * Map Berlin Group transaction list → OfficePlus format
 */
function mapBerlinTransactions(payload, iban) {
  const booked = (payload.transactions && payload.transactions.booked) ||
    payload.booked ||
    (Array.isArray(payload.transactions) ? payload.transactions : []) ||
    [];
  const list = Array.isArray(booked) ? booked : [];
  return list.map((t, i) => {
    const amtObj = t.transactionAmount || t.amount || {};
    const amount = Math.abs(parseFloat(amtObj.amount != null ? amtObj.amount : t.amount) || 0);
    const currency = amtObj.currency || t.currency || 'MDL';
    // credit if creditor is us / positive proprietary bankTransactionCode
    let type = 'debit';
    if (t.creditDebitIndicator === 'CRDT' || t.creditDebitIndicator === 'CREDIT') type = 'credit';
    else if (t.creditDebitIndicator === 'DBIT' || t.creditDebitIndicator === 'DEBIT') type = 'debit';
    else if (t.debtorName && !t.creditorName) type = 'credit';
    else if (parseFloat(amtObj.amount) > 0 && t.creditorName) type = 'debit';
    const counterpart = t.creditorName || t.debtorName ||
      (t.creditorAccount && t.creditorAccount.iban) ||
      (t.debtorAccount && t.debtorAccount.iban) || '';
    return {
      id: t.transactionId || t.entryReference || ('BG-' + i + '-' + Date.now()),
      date: t.bookingDate || t.valueDate || t.date || '',
      type,
      amount,
      currency,
      counterpart,
      description: t.remittanceInformationUnstructured ||
        (Array.isArray(t.remittanceInformationUnstructuredArray) ? t.remittanceInformationUnstructuredArray.join(' ') : '') ||
        t.additionalInformation || '',
      balance: t.balanceAfterTransaction && t.balanceAfterTransaction.balanceAmount
        ? parseFloat(t.balanceAfterTransaction.balanceAmount.amount)
        : undefined,
      iban: iban || '',
      raw: undefined
    };
  });
}

async function maibSyncLive() {
  const cfg = getMaibConfig();
  const token = await maibObtainToken();
  if (!token) throw new Error('Lipsește access token / Project ID + Secret');
  let accountId = cfg.accountId;
  if (!accountId) {
    const accounts = await maibFetchAccounts(token, cfg.consentId);
    const arr = Array.isArray(accounts) ? accounts : [];
    // prefer matching IBAN
    let acc = arr.find(a => a.iban === cfg.iban || (a.account && a.account.iban === cfg.iban));
    if (!acc && arr.length) acc = arr[0];
    if (!acc) throw new Error('Niciun cont returnat de API. Setează Account ID sau Consent-ID.');
    accountId = acc.resourceId || acc.id || acc.accountId;
    if (accountId) saveMaibConfig({ accountId: String(accountId) });
  }
  const payload = await maibFetchTransactions(token, accountId, cfg.consentId);
  const mapped = mapBerlinTransactions(payload, cfg.iban);
  db.maibTransactions = mapped;
  db.maibLastSync = new Date().toISOString();
  db.maibLastError = null;
  saveDb(db);
  return { transactions: mapped, accountId, syncedAt: db.maibLastSync };
}

function demoMaibTransactions() {
  const now = Date.now();
  return [
    { id: 'TX' + (now - 4), date: new Date(now - 4 * 864e5).toISOString().slice(0, 10), type: 'credit', amount: 35400, currency: 'MDL', counterpart: 'Nord Office SRL', description: 'Încasare factură OP-000875', balance: 128400 },
    { id: 'TX' + (now - 3), date: new Date(now - 3 * 864e5).toISOString().slice(0, 10), type: 'debit', amount: 18500, currency: 'MDL', counterpart: 'Furnizor Toner SA', description: 'Plată factură FF-4412', balance: 92900 },
    { id: 'TX' + (now - 2), date: new Date(now - 2 * 864e5).toISOString().slice(0, 10), type: 'debit', amount: 4200, currency: 'MDL', counterpart: 'MAIB', description: 'Comision lunar cont', balance: 88700 },
    { id: 'TX' + (now - 1), date: new Date(now - 1 * 864e5).toISOString().slice(0, 10), type: 'credit', amount: 14500, currency: 'MDL', counterpart: 'ABC SRL', description: 'Încasare OP-000874', balance: 103200 },
    { id: 'TX' + now, date: new Date().toISOString().slice(0, 10), type: 'debit', amount: 6700, currency: 'MDL', counterpart: 'Logistics MD', description: 'Plată transport', balance: 96500 }
  ];
}

function getSfsConfig() {
  const m = (db.integrations && db.integrations.sfs) || {};
  return {
    enabled: !!m.enabled,
    env: m.env || 'test', // test | production
    baseUrl: m.baseUrl || (m.env === 'production' ? 'https://efactura.sfs.md' : 'https://efactura.sfs.md'),
    apiUser: m.apiUser || '',
    apiPassword: m.apiPassword || '',
    idno: m.idno || '',
    token: m.token || ''
  };
}
function saveSfsConfig(partial) {
  db.integrations = db.integrations || {};
  db.integrations.sfs = { ...(db.integrations.sfs || {}), ...partial };
  saveDb(db);
}

function ean13Checksum(digits12) {
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += parseInt(digits12[i], 10) * (i % 2 === 0 ? 1 : 3);
  return String((10 - (sum % 10)) % 10);
}
function generateEAN13(seed) {
  const prefix = '484';
  const used = new Set((db.products || []).map(p => String(p.ean || '').replace(/\D/g, '')).filter(Boolean));
  let n = (db.products || []).length + 1;
  const seedNum = parseInt(String(seed || '').replace(/\D/g, '').slice(-6), 10) || 0;
  for (let a = 0; a < 10000; a++) {
    const body = String(n + seedNum + a).padStart(9, '0').slice(-9);
    const d12 = prefix + body;
    const ean = d12 + ean13Checksum(d12);
    if (!used.has(ean)) return ean;
  }
  const body = String(Date.now()).slice(-9);
  return prefix + body + ean13Checksum(prefix + body);
}

function demoMaibTransactions() {
  const now = Date.now();
  return [
    { id: 'TX' + (now - 4), date: new Date(now - 4 * 864e5).toISOString().slice(0, 10), type: 'credit', amount: 35400, currency: 'MDL', counterpart: 'Nord Office SRL', description: 'Încasare factură OP-000875', balance: 128400 },
    { id: 'TX' + (now - 3), date: new Date(now - 3 * 864e5).toISOString().slice(0, 10), type: 'debit', amount: 18500, currency: 'MDL', counterpart: 'Furnizor Toner SA', description: 'Plată factură FF-4412', balance: 92900 },
    { id: 'TX' + (now - 2), date: new Date(now - 2 * 864e5).toISOString().slice(0, 10), type: 'debit', amount: 4200, currency: 'MDL', counterpart: 'MAIB', description: 'Comision lunar cont', balance: 88700 },
    { id: 'TX' + (now - 1), date: new Date(now - 1 * 864e5).toISOString().slice(0, 10), type: 'credit', amount: 14500, currency: 'MDL', counterpart: 'ABC SRL', description: 'Încasare OP-000874', balance: 103200 },
    { id: 'TX' + now, date: new Date().toISOString().slice(0, 10), type: 'debit', amount: 6700, currency: 'MDL', counterpart: 'Logistics MD', description: 'Plată transport', balance: 96500 }
  ];
}

function demoSfsReceivedInvoices() {
  return [
    {
      id: 'SFS-R-1001',
      seria: 'EF',
      number: '2026004412',
      date: '2026-09-25',
      supplier: 'Furnizor Toner SA',
      supplierIdno: '1003600012345',
      total: 18500,
      status: 'Primită',
      lines: [
        { name: 'Toner HP CF280A Original', qty: 20, unit: 'buc', price: 185, code: '' },
        { name: 'Hârtie A4 80g 500 coli', qty: 50, unit: 'top', price: 67, code: '' }
      ]
    },
    {
      id: 'SFS-R-1002',
      seria: 'EF',
      number: '2026004490',
      date: '2026-09-28',
      supplier: 'Office Trade SRL',
      supplierIdno: '1003600098765',
      total: 9200,
      status: 'Primită',
      lines: [
        { name: 'Pix albastru 1.0mm', qty: 1000, unit: 'buc', price: 2.5, code: '' },
        { name: 'Dosar carton A4', qty: 200, unit: 'buc', price: 8.5, code: '4840000099990' }
      ]
    }
  ];
}

function importSfsLinesToProducts(invoice) {
  db.products = db.products || [];
  const created = [];
  const lines = invoice.lines || [];
  lines.forEach((line, idx) => {
    let ean = String(line.code || '').replace(/\D/g, '');
    if (ean.length === 13) {
      // validate checksum loosely — regenerate if invalid length
    } else {
      ean = generateEAN13(String(invoice.number || '') + idx + Date.now());
    }
    const existing = db.products.find(p =>
      (p.ean && p.ean === ean) ||
      (p.name && p.name.toLowerCase() === String(line.name || '').toLowerCase())
    );
    if (existing) {
      created.push({ action: 'exists', product: existing, line });
      return;
    }
    const art = 'SFS-' + String(invoice.number || 'IMP').slice(-6) + '-' + String(idx + 1).padStart(2, '0');
    const prod = {
      id: nextId(db.products),
      art,
      name: line.name || 'Articol SFS',
      ean,
      grup: 'Achiziții SFS',
      stoc: Number(line.qty) || 0,
      pret: Number(line.price) || 0,
      online: Number(line.price) || 0,
      status: 'Activ',
      depozit: db.warehouse || 'Bălți Central',
      src: 'sfs:' + (invoice.id || invoice.number)
    };
    db.products.push(prod);
    created.push({ action: 'created', product: prod, line });
  });
  saveDb(db);
  return created;
}


function getGDriveConfig() {
  const o = (db.settings && (db.settings.googleApi || db.settings.oauth)) || {}; // legacy key support
  const g = (db.integrations && db.integrations.gdrive) || {};
  return {
    clientId: o.googleClientId || g.clientId || process.env.GOOGLE_CLIENT_ID || '',
    clientSecret: o.googleClientSecret || g.clientSecret || process.env.GOOGLE_CLIENT_SECRET || '',
    refreshToken: g.refreshToken || '',
    accessToken: g.accessToken || '',
    tokenExpiry: g.tokenExpiry || 0,
    folderId: g.folderId || 'root',
    folderName: g.folderName || 'OfficePlus_Scanate'
  };
}

function saveGDriveTokens(partial) {
  db.integrations = db.integrations || {};
  db.integrations.gdrive = { ...(db.integrations.gdrive || {}), ...partial };
  saveDb(db);
}

async function refreshGDriveAccessToken() {
  const cfg = getGDriveConfig();
  if (!cfg.refreshToken || !cfg.clientId || !cfg.clientSecret) return null;
  const res = await httpPostForm('https://oauth2.googleapis.com/token', {
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    refresh_token: cfg.refreshToken,
    grant_type: 'refresh_token'
  });
  if (!res.json || !res.json.access_token) return null;
  const exp = Date.now() + ((res.json.expires_in || 3600) - 60) * 1000;
  saveGDriveTokens({ accessToken: res.json.access_token, tokenExpiry: exp });
  return res.json.access_token;
}

async function getValidGDriveToken() {
  const cfg = getGDriveConfig();
  if (cfg.accessToken && cfg.tokenExpiry > Date.now()) return cfg.accessToken;
  return await refreshGDriveAccessToken();
}

function httpRequestRaw(method, urlStr, headers, bodyBuf) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const req = https.request({
      hostname: u.hostname,
      path: u.pathname + u.search,
      method,
      headers: headers || {}
    }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        let json = null;
        try { json = JSON.parse(buf.toString('utf8')); } catch (e) {}
        resolve({ status: res.statusCode, json, text: buf.toString('utf8'), buf });
      });
    });
    req.on('error', reject);
    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

async function ensureDriveFolder(token, folderName) {
  // search existing
  const q = encodeURIComponent("name='" + folderName.replace(/'/g, "\\'") + "' and mimeType='application/vnd.google-apps.folder' and trashed=false");
  const search = await httpRequestRaw('GET',
    'https://www.googleapis.com/drive/v3/files?q=' + q + '&fields=files(id,name)',
    { Authorization: 'Bearer ' + token });
  if (search.json && search.json.files && search.json.files.length) {
    return search.json.files[0].id;
  }
  // create
  const meta = JSON.stringify({ name: folderName, mimeType: 'application/vnd.google-apps.folder' });
  const created = await httpRequestRaw('POST',
    'https://www.googleapis.com/drive/v3/files?fields=id,name',
    { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(meta) },
    Buffer.from(meta));
  if (created.json && created.json.id) return created.json.id;
  throw new Error('Nu s-a putut crea folderul Drive: ' + (created.text || ''));
}

async function uploadToDrive(token, folderId, localPath, fileName) {
  const data = fs.readFileSync(localPath);
  const boundary = '----op' + Date.now();
  const mime = fileName.toLowerCase().endsWith('.pdf') ? 'application/pdf'
    : /\.png$/i.test(fileName) ? 'image/png'
    : /\.jpe?g$/i.test(fileName) ? 'image/jpeg'
    : 'application/octet-stream';
  const meta = JSON.stringify({ name: fileName, parents: [folderId] });
  const parts = [
    '--' + boundary + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + meta + '\r\n',
    '--' + boundary + '\r\nContent-Type: ' + mime + '\r\n\r\n'
  ];
  const head = Buffer.from(parts[0] + parts[1], 'utf8');
  const tail = Buffer.from('\r\n--' + boundary + '--\r\n', 'utf8');
  const body = Buffer.concat([head, data, tail]);
  const res = await httpRequestRaw('POST',
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
    {
      Authorization: 'Bearer ' + token,
      'Content-Type': 'multipart/related; boundary=' + boundary,
      'Content-Length': body.length
    },
    body);
  if (res.status >= 200 && res.status < 300 && res.json) return res.json;
  throw new Error('Upload eșuat: ' + (res.text || res.status));
}


function getGoogleApiConfig() {
  const o = (db.settings && (db.settings.googleApi || db.settings.oauth)) || {}; // legacy key support
  return {
    google: {
      clientId: o.googleClientId || process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: o.googleClientSecret || process.env.GOOGLE_CLIENT_SECRET || '',
      authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
      tokenUrl: 'https://oauth2.googleapis.com/token',
      userUrl: 'https://www.googleapis.com/oauth2/v2/userinfo',
      scope: 'openid email profile'
    }
  };
}

function httpPostForm(urlStr, formObj) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const body = new URLSearchParams(formObj).toString();
    const req = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, json: JSON.parse(data) }); }
        catch (e) { resolve({ status: res.statusCode, text: data }); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function httpGetJson(urlStr, token) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const req = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
      headers: { Authorization: 'Bearer ' + token, Accept: 'application/json' }
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, json: JSON.parse(data) }); }
        catch (e) { resolve({ status: res.statusCode, text: data }); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}


function canAccess(role, moduleId) {
  const perms = ROLE_PERMS[role] || ROLE_PERMS['Read-only'];
  if (perms.includes('*')) return true;
  return perms.includes(moduleId);
}



function createSession(user) {
  const token = crypto.randomBytes(32).toString('hex');
  const exp = Date.now() + 12 * 60 * 60 * 1000; // 12h
  sessions.set(token, { userId: user.id, name: user.name, role: user.role, modules: user.modules, exp });
  return token;
}
function getSession(req) {
  const auth = req.headers['authorization'] || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : (req.headers['x-session-token'] || '');
  if (!token) return null;
  const s = sessions.get(token);
  if (!s || s.exp < Date.now()) {
    if (s) sessions.delete(token);
    return null;
  }
  return s;
}
function publicUser(u) {
  return { id: u.id, name: u.name, role: u.role, modules: u.modules, tfa: u.tfa, status: u.status };
}

function send(res, code, data) {
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Session-Token'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = '';
    req.on('data', c => { buf += c; if (buf.length > 15e6) reject(new Error('too large')); });
    req.on('end', () => {
      try { resolve(buf ? JSON.parse(buf) : {}); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function mime(p) {
  if (p.endsWith('.html')) return 'text/html; charset=utf-8';
  if (p.endsWith('.js')) return 'application/javascript';
  if (p.endsWith('.css')) return 'text/css';
  if (p.endsWith('.json')) return 'application/json';
  return 'application/octet-stream';
}

function nextId(arr) {
  return arr.length ? Math.max(...arr.map(x => +x.id || 0)) + 1 : 1;
}

function requireAuth(req, res, needAdmin) {
  const s = getSession(req);
  if (!s) {
    send(res, 401, { error: 'Neautentificat' });
    return null;
  }
  if (needAdmin && s.role !== 'Administrator') {
    send(res, 403, { error: 'Doar Administrator' });
    return null;
  }
  return s;
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Session-Token'
    });
    return res.end();
  }

  const u = new URL(req.url, 'http://127.0.0.1');
  const p = u.pathname;

  try {
    // ---- AUTH ----
    

    // Google account connect callback (Drive / Calendar only — NOT user login)
    if (p === '/api/google/callback' && req.method === 'GET') {
      const code = u.searchParams.get('code');
      const state = u.searchParams.get('state');
      const err = u.searchParams.get('error');
      if (err) {
        res.writeHead(302, { Location: '/index.html?gdrive=error' });
        return res.end();
      }
      const pending = googleConnectPending.get(state);
      googleConnectPending.delete(state);
      if (!pending || pending.exp < Date.now()) {
        res.writeHead(302, { Location: '/index.html?gdrive=error' });
        return res.end();
      }
      const provider = pending.provider;
      const gcfg = getGoogleApiConfig().google;
      const redirectUri = 'http://127.0.0.1:' + PORT + '/api/google/callback';
      try {
        const tokenRes = await httpPostForm(gcfg.tokenUrl || 'https://oauth2.googleapis.com/token', {
          code,
          client_id: gcfg.clientId,
          client_secret: gcfg.clientSecret,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code'
        });
        if (!tokenRes.json || !tokenRes.json.access_token) {
          res.writeHead(302, { Location: '/index.html?gdrive=error' });
          return res.end();
        }
        const access = tokenRes.json.access_token;
        if (provider === 'gcal') {
          saveGCalTokens({
            accessToken: access,
            refreshToken: tokenRes.json.refresh_token || getGCalConfig().refreshToken,
            tokenExpiry: Date.now() + ((tokenRes.json.expires_in || 3600) - 60) * 1000
          });
          res.writeHead(302, { Location: '/index.html?gcal=ok' });
          return res.end();
        }
        // default: gdrive
        saveGDriveTokens({
          accessToken: access,
          refreshToken: tokenRes.json.refresh_token || getGDriveConfig().refreshToken,
          tokenExpiry: Date.now() + ((tokenRes.json.expires_in || 3600) - 60) * 1000
        });
        try {
          const folderId = await ensureDriveFolder(access, getGDriveConfig().folderName || 'OfficePlus_Scanate');
          saveGDriveTokens({ folderId });
        } catch (e) { console.error(e.message); }
        res.writeHead(302, { Location: '/index.html?gdrive=ok' });
        return res.end();
      } catch (e) {
        console.error(e);
        res.writeHead(302, { Location: '/index.html?gdrive=error' });
        return res.end();
      }
    }

    // Google Drive connect
    if (p === '/api/gdrive/auth/start' && req.method === 'GET') {
      const cfg = getGDriveConfig();
      if (!cfg.clientId) return send(res, 400, { error: 'Configurează Google Client ID în Setări → Google Drive API' });
      const state = crypto.randomBytes(16).toString('hex');
      googleConnectPending.set(state, { provider: 'gdrive', exp: Date.now() + 10 * 60 * 1000 });
      const redirectUri = 'http://127.0.0.1:' + PORT + '/api/google/callback';
      const params = new URLSearchParams({
        client_id: cfg.clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: 'https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.email',
        state,
        access_type: 'offline',
        prompt: 'consent'
      });
      return send(res, 200, { url: 'https://accounts.google.com/o/oauth2/v2/auth?' + params.toString() });
    }

    // Google Drive status
    
    // Google Calendar connect
    if (p === '/api/gcal/auth/start' && req.method === 'GET') {
      const cfg = getGCalConfig();
      if (!cfg.clientId) return send(res, 400, { error: 'Configurează Google Client ID în Setări → Google Drive API' });
      const state = crypto.randomBytes(16).toString('hex');
      googleConnectPending.set(state, { provider: 'gcal', exp: Date.now() + 10 * 60 * 1000 });
      const redirectUri = 'http://127.0.0.1:' + PORT + '/api/google/callback';
      const params = new URLSearchParams({
        client_id: cfg.clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: 'https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/userinfo.email',
        state,
        access_type: 'offline',
        prompt: 'consent'
      });
      return send(res, 200, { url: 'https://accounts.google.com/o/oauth2/v2/auth?' + params.toString() });
    }

    if (p === '/api/gcal/status' && req.method === 'GET') {
      const cfg = getGCalConfig();
      return send(res, 200, {
        configured: !!(cfg.clientId && cfg.clientSecret),
        connected: !!(cfg.refreshToken || (cfg.accessToken && cfg.tokenExpiry > Date.now())),
        calendarId: cfg.calendarId
      });
    }

    if (p === '/api/gcal/events' && req.method === 'GET') {
      try {
        let token = await getValidGCalToken();
        if (!token) return send(res, 401, { error: 'Conectează Google Calendar' });
        const cfg = getGCalConfig();
        const timeMin = u.searchParams.get('timeMin') || new Date().toISOString();
        const timeMax = u.searchParams.get('timeMax') || new Date(Date.now() + 30 * 864e5).toISOString();
        const maxResults = u.searchParams.get('max') || '20';
        const url = 'https://www.googleapis.com/calendar/v3/calendars/' + encodeURIComponent(cfg.calendarId) +
          '/events?timeMin=' + encodeURIComponent(timeMin) +
          '&timeMax=' + encodeURIComponent(timeMax) +
          '&singleEvents=true&orderBy=startTime&maxResults=' + maxResults;
        const resG = await httpRequestRaw('GET', url, { Authorization: 'Bearer ' + token });
        if (resG.status >= 400) return send(res, resG.status, { error: resG.text || 'Calendar API error' });
        const items = (resG.json && resG.json.items) || [];
        const events = items.map(ev => ({
          id: ev.id,
          summary: ev.summary || '(fără titlu)',
          description: ev.description || '',
          start: (ev.start && (ev.start.dateTime || ev.start.date)) || '',
          end: (ev.end && (ev.end.dateTime || ev.end.date)) || '',
          htmlLink: ev.htmlLink || '',
          location: ev.location || ''
        }));
        return send(res, 200, { events, calendarId: cfg.calendarId });
      } catch (e) {
        return send(res, 500, { error: e.message });
      }
    }

    if (p === '/api/gcal/events' && req.method === 'POST') {
      try {
        let token = await getValidGCalToken();
        if (!token) return send(res, 401, { error: 'Conectează Google Calendar' });
        const cfg = getGCalConfig();
        const body = await readBody(req);
        const summary = body.summary || body.title || 'Eveniment OfficePlus';
        const description = body.description || body.note || '';
        const start = body.start;
        const end = body.end || (start ? new Date(new Date(start).getTime() + 3600000).toISOString() : null);
        if (!start) return send(res, 400, { error: 'start obligatoriu (ISO date)' });
        const allDay = body.allDay === true;
        const event = {
          summary,
          description,
          location: body.location || ''
        };
        if (allDay) {
          event.start = { date: String(start).slice(0, 10) };
          event.end = { date: String(end || start).slice(0, 10) };
        } else {
          event.start = { dateTime: new Date(start).toISOString() };
          event.end = { dateTime: new Date(end).toISOString() };
        }
        const payload = JSON.stringify(event);
        const resG = await httpRequestRaw('POST',
          'https://www.googleapis.com/calendar/v3/calendars/' + encodeURIComponent(cfg.calendarId) + '/events',
          {
            Authorization: 'Bearer ' + token,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
          },
          Buffer.from(payload));
        if (resG.status >= 400) return send(res, resG.status, { error: resG.text || 'Create failed' });
        audit('gcal_create', { summary, id: resG.json && resG.json.id });
        return send(res, 200, { ok: true, event: resG.json });
      } catch (e) {
        return send(res, 500, { error: e.message });
      }
    }


    if (p === '/api/gdrive/status' && req.method === 'GET') {
      const cfg = getGDriveConfig();
      return send(res, 200, {
        configured: !!(cfg.clientId && cfg.clientSecret),
        connected: !!(cfg.refreshToken || (cfg.accessToken && cfg.tokenExpiry > Date.now())),
        folderId: cfg.folderId,
        folderName: cfg.folderName
      });
    }

    // Upload one file from scanate tree path
    if (p === '/api/gdrive/upload' && req.method === 'POST') {
      const body = await readBody(req);
      const rel = body.path || body.file;
      if (!rel) return send(res, 400, { error: 'path required' });
      if (String(rel).includes('..')) return send(res, 403, { error: 'Forbidden' });
      const localPath = path.join(SCAN_DIR, rel);
      if (!fs.existsSync(localPath) || !fs.statSync(localPath).isFile()) {
        // try basename only in SCAN_DIR
        const alt = path.join(SCAN_DIR, path.basename(rel));
        if (!fs.existsSync(alt)) return send(res, 404, { error: 'Fișier local negăsit' });
      }
      const fp = fs.existsSync(path.join(SCAN_DIR, rel)) ? path.join(SCAN_DIR, rel) : path.join(SCAN_DIR, path.basename(rel));
      try {
        let token = await getValidGDriveToken();
        if (!token) return send(res, 401, { error: 'Conectează Google Drive mai întâi' });
        const cfg = getGDriveConfig();
        let folderId = cfg.folderId;
        if (!folderId || folderId === 'root') {
          folderId = await ensureDriveFolder(token, cfg.folderName || 'OfficePlus_Scanate');
          saveGDriveTokens({ folderId });
        }
        const fileName = path.basename(fp);
        const uploaded = await uploadToDrive(token, folderId, fp, fileName);
        db.gdriveUploads = db.gdriveUploads || [];
        db.gdriveUploads.unshift({
          id: Date.now(),
          local: rel,
          driveId: uploaded.id,
          name: uploaded.name,
          link: uploaded.webViewLink,
          at: new Date().toISOString(),
          user: (getSession(req) || {}).name || 'local'
        });
        if (db.gdriveUploads.length > 100) db.gdriveUploads.length = 100;
        saveDb(db);
        audit('gdrive_upload', { file: rel, driveId: uploaded.id });
        return send(res, 200, { ok: true, file: uploaded });
      } catch (e) {
        return send(res, 500, { ok: false, error: e.message });
      }
    }

    // Upload all unsorted/sorted files in scanate (batch)
    if (p === '/api/gdrive/upload-all' && req.method === 'POST') {
      try {
        let token = await getValidGDriveToken();
        if (!token) return send(res, 401, { error: 'Conectează Google Drive mai întâi' });
        const cfg = getGDriveConfig();
        let folderId = cfg.folderId;
        if (!folderId || folderId === 'root') {
          folderId = await ensureDriveFolder(token, cfg.folderName || 'OfficePlus_Scanate');
          saveGDriveTokens({ folderId });
        }
        const tree = listScansTree().filter(x => x.type === 'file');
        const results = [];
        for (const f of tree) {
          try {
            const fp = path.join(SCAN_DIR, f.path);
            const uploaded = await uploadToDrive(token, folderId, fp, f.name);
            results.push({ ok: true, local: f.path, driveId: uploaded.id, link: uploaded.webViewLink });
          } catch (e) {
            results.push({ ok: false, local: f.path, error: e.message });
          }
        }
        return send(res, 200, { ok: true, count: results.filter(x => x.ok).length, results });
      } catch (e) {
        return send(res, 500, { ok: false, error: e.message });
      }
    }

    if (p === '/api/gdrive/uploads' && req.method === 'GET') {
      return send(res, 200, db.gdriveUploads || []);
    }


    
    // ---- MAIB ----
    if (p === '/api/maib/config' && req.method === 'GET') {
      const c = getMaibConfig();
      return send(res, 200, { ...c, clientSecret: c.clientSecret ? '••••' : '' });
    }
    if (p === '/api/maib/config' && req.method === 'PUT') {
      const body = await readBody(req);
      const prev = getMaibConfig();
      saveMaibConfig({
        enabled: body.enabled !== undefined ? !!body.enabled : prev.enabled,
        baseUrl: body.baseUrl || prev.baseUrl,
        clientId: body.clientId !== undefined ? body.clientId : prev.clientId,
        clientSecret: body.clientSecret && body.clientSecret !== '••••' ? body.clientSecret : prev.clientSecret,
        projectId: body.projectId !== undefined ? body.projectId : (body.clientId !== undefined ? body.clientId : prev.projectId),
        projectSecret: body.projectSecret && body.projectSecret !== '••••' ? body.projectSecret : (body.clientSecret && body.clientSecret !== '••••' ? body.clientSecret : prev.projectSecret),
        iban: body.iban !== undefined ? body.iban : prev.iban,
        accountId: body.accountId !== undefined ? body.accountId : prev.accountId,
        consentId: body.consentId !== undefined ? body.consentId : prev.consentId,
        accessToken: body.accessToken !== undefined ? body.accessToken : prev.accessToken,
        mode: body.mode || prev.mode,
        psuIp: body.psuIp || prev.psuIp,
        tokenUrl: body.tokenUrl || prev.tokenUrl || 'https://api.maibmerchants.md/v1/generate-token'
      });
      return send(res, 200, { ok: true });
    }
    
    if (p === '/api/maib/transactions' && req.method === 'GET') {
      const cfg = getMaibConfig();
      let txs = db.maibTransactions || [];
      let mode = cfg.mode;
      let error = null;
      if (cfg.mode === 'live' && cfg.enabled) {
        try {
          const live = await maibSyncLive();
          txs = live.transactions;
          mode = 'live';
        } catch (e) {
          error = e.message;
          db.maibLastError = e.message;
          saveDb(db);
          if (!txs.length) txs = demoMaibTransactions();
          mode = 'live-error';
        }
      } else if (!txs.length) {
        txs = demoMaibTransactions();
        db.maibTransactions = txs;
        saveDb(db);
        mode = 'demo';
      }
      const credits = txs.filter(t => t.type === 'credit').reduce((a, t) => a + Number(t.amount), 0);
      const debits = txs.filter(t => t.type === 'debit').reduce((a, t) => a + Number(t.amount), 0);
      const lastBal = [...txs].reverse().find(t => t.balance != null);
      return send(res, 200, {
        mode,
        iban: cfg.iban,
        accountId: cfg.accountId,
        consentId: cfg.consentId ? 'set' : '',
        lastSync: db.maibLastSync || null,
        error,
        transactions: txs,
        summary: {
          credits,
          debits,
          net: credits - debits,
          count: txs.length,
          balance: lastBal ? lastBal.balance : 0
        }
      });
    }

    if (p === '/api/maib/sync' && req.method === 'POST') {
      try {
        saveMaibConfig({ mode: 'live', enabled: true });
        const live = await maibSyncLive();
        return send(res, 200, { ok: true, count: live.transactions.length, accountId: live.accountId, syncedAt: live.syncedAt });
      } catch (e) {
        return send(res, 502, { ok: false, error: e.message, hint: 'Verifică Base URL, Project ID/Secret, Consent-ID, Account ID. Open Banking necesită autorizare BNM (TPP).' });
      }
    }

    if (p === '/api/maib/test-token' && req.method === 'POST') {
      try {
        const tok = await maibObtainToken();
        return send(res, 200, { ok: !!tok, tokenPreview: tok ? (tok.slice(0, 8) + '…') : null });
      } catch (e) {
        return send(res, 502, { ok: false, error: e.message });
      }
    }

if (p === '/api/maib/import' && req.method === 'POST') {
      // Import statement JSON/CSV rows from maib business export
      const body = await readBody(req);
      let rows = Array.isArray(body.transactions) ? body.transactions : (Array.isArray(body) ? body : []);
      if (!rows.length && body.csv) {
        const lines = String(body.csv).trim().split(/\r?\n/);
        const hdr = lines.shift().split(/[;,]/);
        rows = lines.map(line => {
          const c = line.split(/[;,]/);
          const o = {};
          hdr.forEach((h, i) => o[h.trim()] = (c[i] || '').trim());
          return {
            id: o.id || o.ID || ('IMP' + Date.now() + Math.random()),
            date: o.date || o.Data || o.DATE,
            type: /credit|incas|încas/i.test(o.type || o.Tip || '') || Number(o.credit || o.Credit || 0) > 0 ? 'credit' : 'debit',
            amount: Number(o.amount || o.Suma || o.credit || o.debit || 0),
            currency: o.currency || o.Valuta || 'MDL',
            counterpart: o.counterpart || o.Partener || o.Beneficiar || '',
            description: o.description || o.Descriere || o.Detalii || '',
            balance: Number(o.balance || o.Sold || 0)
          };
        });
      }
      db.maibTransactions = rows;
      saveDb(db);
      return send(res, 200, { ok: true, count: rows.length });
    }

    // ---- SFS e-Factura ----
    if (p === '/api/sfs/config' && req.method === 'GET') {
      const c = getSfsConfig();
      return send(res, 200, { ...c, apiPassword: c.apiPassword ? '••••' : '' });
    }
    if (p === '/api/sfs/config' && req.method === 'PUT') {
      const body = await readBody(req);
      const prev = getSfsConfig();
      saveSfsConfig({
        enabled: body.enabled !== undefined ? !!body.enabled : prev.enabled,
        env: body.env || prev.env,
        baseUrl: body.baseUrl || prev.baseUrl,
        apiUser: body.apiUser !== undefined ? body.apiUser : prev.apiUser,
        apiPassword: body.apiPassword && body.apiPassword !== '••••' ? body.apiPassword : prev.apiPassword,
        idno: body.idno !== undefined ? body.idno : prev.idno,
        token: body.token !== undefined ? body.token : prev.token
      });
      return send(res, 200, { ok: true });
    }
    if (p === '/api/sfs/received' && req.method === 'GET') {
      const cfg = getSfsConfig();
      // Live: call SFS e-Factura API with API user (GetBuyerInvoices / similar)
      // Without live credentials, return stored or demo received invoices
      let list = db.sfsReceived || [];
      if (!list.length) {
        list = demoSfsReceivedInvoices();
        db.sfsReceived = list;
        saveDb(db);
      }
      return send(res, 200, { mode: cfg.apiUser ? 'configured' : 'demo', env: cfg.env, invoices: list });
    }
    if (p === '/api/sfs/sync' && req.method === 'POST') {
      const cfg = getSfsConfig();
      // Placeholder for live SOAP/REST call to efactura.sfs.md with apiUser/password
      // Merges demo/new invoices for UI pipeline
      const incoming = demoSfsReceivedInvoices();
      db.sfsReceived = db.sfsReceived || [];
      let added = 0;
      incoming.forEach(inv => {
        if (!db.sfsReceived.find(x => x.id === inv.id || (x.number === inv.number && x.seria === inv.seria))) {
          db.sfsReceived.unshift(inv);
          added++;
        }
      });
      saveDb(db);
      audit('sfs_sync', { added, user: cfg.apiUser || 'demo' });
      return send(res, 200, { ok: true, added, total: db.sfsReceived.length, note: cfg.apiUser ? 'Sync cu credențiale salvate (endpoint live la activare producție)' : 'Mod demo — completează user API SFS pentru producție' });
    }
    if (p === '/api/sfs/import-products' && req.method === 'POST') {
      const body = await readBody(req);
      const invId = body.invoiceId;
      const inv = (db.sfsReceived || []).find(x => x.id === invId || x.number === invId);
      if (!inv) return send(res, 404, { error: 'Factură negăsită' });
      const result = importSfsLinesToProducts(inv);
      inv.productsImported = true;
      saveDb(db);
      return send(res, 200, {
        ok: true,
        created: result.filter(x => x.action === 'created').length,
        exists: result.filter(x => x.action === 'exists').length,
        items: result.map(x => ({
          action: x.action,
          art: x.product.art,
          name: x.product.name,
          ean: x.product.ean,
          stoc: x.product.stoc,
          pret: x.product.pret
        }))
      });
    }
    if (p === '/api/sfs/import-all-products' && req.method === 'POST') {
      const list = db.sfsReceived || [];
      let created = 0, exists = 0;
      const details = [];
      list.forEach(inv => {
        const r = importSfsLinesToProducts(inv);
        inv.productsImported = true;
        r.forEach(x => {
          if (x.action === 'created') created++;
          else exists++;
          details.push({ invoice: inv.number, ...x.product, action: x.action });
        });
      });
      saveDb(db);
      return send(res, 200, { ok: true, created, exists, details: details.slice(0, 50) });
    }


    if (p === '/api/scan/list' && req.method === 'GET') {
      const sess = getSession(req);
      // allow without auth for local use too
      return send(res, 200, { dir: SCAN_DIR, vuescan: findVueScan(), files: listScans(), links: db.scans || [] });
    }

    // Scan: launch VueScan
    if (p === '/api/scan/start' && req.method === 'POST') {
      const body = await readBody(req).catch(() => ({}));
      const client = body.client || '';
      const note = body.note || '';
      const exe = findVueScan();
      // ensure output folder exists
      if (!fs.existsSync(SCAN_DIR)) fs.mkdirSync(SCAN_DIR, { recursive: true });

      // Write a marker job file for CRM link
      const jobId = Date.now().toString(36);
      const job = {
        id: jobId,
        client,
        note,
        user: (getSession(req) || {}).name || 'local',
        started: new Date().toISOString(),
        status: 'scanning'
      };
      db.scanJobs = db.scanJobs || [];
      db.scanJobs.unshift(job);
      if (db.scanJobs.length > 50) db.scanJobs.length = 50;
      saveDb(db);

      if (!exe) {
        return send(res, 200, {
          ok: false,
          jobId,
          error: 'VueScan nu a fost găsit. Instalează VueScan sau setează VUESCAN_PATH.',
          dir: SCAN_DIR,
          hint: 'Poți copia manual fișierele scanate în folderul scanate/'
        });
      }

      try {
        // Launch VueScan; user scans and saves into scanate folder
        // VueScan GUI — open and let user save to SCAN_DIR
        const child = spawn(exe, [], {
          detached: true,
          stdio: 'ignore',
          cwd: SCAN_DIR,
          windowsHide: false
        });
        child.unref();
        audit('scan_start', { jobId, client, exe });
        return send(res, 200, {
          ok: true,
          jobId,
          message: 'VueScan a fost deschis. Salvează scanarea în folderul scanate.',
          dir: SCAN_DIR,
          client
        });
      } catch (e) {
        return send(res, 500, { ok: false, error: e.message, dir: SCAN_DIR });
      }
    }

    // Scan: register file to CRM
    if (p === '/api/scan/link' && req.method === 'POST') {
      const body = await readBody(req);
      const entry = {
        id: nextId(db.scans || []),
        file: body.file,
        client: body.client || '',
        note: body.note || '',
        user: (getSession(req) || {}).name || 'local',
        at: new Date().toISOString()
      };
      db.scans = db.scans || [];
      db.scans.unshift(entry);
      saveDb(db);
      try { pushHistory('scans', entry.id, 'link', entry.user, { file: entry.file, client: entry.client }); } catch (e) {}
      return send(res, 200, entry);
    }

    // Serve files from scanate/
    if (p.startsWith('/scanate/') && req.method === 'GET') {
      const fname = decodeURIComponent(p.slice('/scanate/'.length));
      if (fname.includes('..') || fname.includes('/') || fname.includes('\\\\')) {
        return send(res, 403, { error: 'Forbidden' });
      }
      const fp = path.join(SCAN_DIR, fname);
      if (!fs.existsSync(fp) || !fs.statSync(fp).isFile()) {
        return send(res, 404, { error: 'Not found' });
      }
      const data = fs.readFileSync(fp);
      const ext = path.extname(fname).toLowerCase();
      const types = { '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.tif': 'image/tiff', '.tiff': 'image/tiff' };
      res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Access-Control-Allow-Origin': '*' });
      return res.end(data);
    }

    // Open scanate folder in Explorer
    if (p === '/api/scan/open-folder' && req.method === 'POST') {
      if (!fs.existsSync(SCAN_DIR)) fs.mkdirSync(SCAN_DIR, { recursive: true });
      try {
        if (process.platform === 'win32') {
          spawn('explorer.exe', [SCAN_DIR], { detached: true, stdio: 'ignore' }).unref();
        } else {
          spawn('xdg-open', [SCAN_DIR], { detached: true, stdio: 'ignore' }).unref();
        }
        return send(res, 200, { ok: true, dir: SCAN_DIR });
      } catch (e) {
        return send(res, 200, { ok: true, dir: SCAN_DIR, error: e.message });
      }
    }


    if (p === '/api/auth/login' && req.method === 'POST') {
      const ip = clientIp(req);
      if (!checkLoginRate(ip)) {
        audit('login_blocked', { ip });
        return send(res, 429, { error: 'Prea multe încercări. Reîncearcă în 5 minute.' });
      }
      const body = await readBody(req);
      const name = String(body.username || body.name || '').trim();
      const password = String(body.password || '');
      const user = (db.users || []).find(x => x.name === name);
      if (!user || user.status === 'Blocat') {
        recordLoginFail(ip);
        audit('login_fail', { ip, name });
        return send(res, 401, { error: 'Utilizator sau parolă invalidă' });
      }
      if (!verifyPassword(password, user.salt, user.passwordHash)) {
        recordLoginFail(ip);
        audit('login_fail', { ip, name });
        return send(res, 401, { error: 'Utilizator sau parolă invalidă' });
      }
      recordLoginOk(ip);
      const token = createSession(user);
      audit('login_ok', { ip, name: user.name, role: user.role });
      return send(res, 200, { token, user: publicUser(user) });
    }

    if (p === '/api/auth/logout' && req.method === 'POST') {
      const auth = req.headers['authorization'] || '';
      const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
      if (token) sessions.delete(token);
      return send(res, 200, { ok: true });
    }

    if (p === '/api/auth/me' && req.method === 'GET') {
      const s = getSession(req);
      if (!s) return send(res, 401, { error: 'Neautentificat' });
      const user = (db.users || []).find(x => x.id === s.userId);
      if (!user) return send(res, 401, { error: 'Sesiune invalidă' });
      return send(res, 200, { user: publicUser(user) });
    }

    if (p === '/api/auth/change-password' && req.method === 'POST') {
      const s = requireAuth(req, res);
      if (!s) return;
      const body = await readBody(req);
      const user = (db.users || []).find(x => x.id === s.userId);
      if (!user) return send(res, 404, { error: 'User not found' });
      if (!verifyPassword(body.currentPassword || '', user.salt, user.passwordHash)) {
        return send(res, 400, { error: 'Parola curentă greșită' });
      }
      if (!body.newPassword || String(body.newPassword).length < 4) {
        return send(res, 400, { error: 'Parola nouă prea scurtă (min 4)' });
      }
      const h = hashPassword(body.newPassword);
      user.salt = h.salt;
      user.passwordHash = h.hash;
      saveDb(db);
      return send(res, 200, { ok: true });
    }

    
    if (p === '/api/auth/permissions' && req.method === 'GET') {
      const sess = getSession(req);
      if (!sess) return send(res, 401, { error: 'Neautentificat' });
      const perms = ROLE_PERMS[sess.role] || ROLE_PERMS['Read-only'];
      return send(res, 200, { role: sess.role, modules: perms, matrix: ROLE_PERMS });
    }

    if (p === '/api/auth/audit' && req.method === 'GET') {
      const sess = requireAuth(req, res, true);
      if (!sess) return;
      return send(res, 200, auditLog.slice(0, 100));
    }

    if (p === '/api/auth/refresh' && req.method === 'POST') {
      const sess = getSession(req);
      if (!sess) return send(res, 401, { error: 'Neautentificat' });
      sess.exp = Date.now() + 12 * 60 * 60 * 1000;
      return send(res, 200, { ok: true, exp: sess.exp });
    }

    if (p === '/api/history' && req.method === 'GET') {
      const sess = requireAuth(req, res);
      if (!sess) return;
      const entity = u.searchParams.get('entity');
      let list = entityHistory;
      if (entity) list = list.filter(x => x.entity === entity);
      return send(res, 200, list.slice(0, 100));
    }

    if (p === '/api/counters' && req.method === 'GET') {
      const sess = requireAuth(req, res);
      if (!sess) return;
      return send(res, 200, db.counters || { invoice: 876, order: 871, product: 100 });
    }
    if (p === '/api/counters/next' && req.method === 'POST') {
      const sess = requireAuth(req, res);
      if (!sess) return;
      const body = await readBody(req);
      const kind = body.kind || 'invoice';
      db.counters = db.counters || { invoice: 876, order: 871, product: 100 };
      db.counters[kind] = (db.counters[kind] || 0) + 1;
      const serie = (db.settings && db.settings.serie) || 'OP';
      saveDb(db);
      const num = serie + '-' + String(db.counters[kind]).padStart(6, '0');
      return send(res, 200, { number: num, counter: db.counters[kind] });
    }

    if (p === '/api/health') {
      return send(res, 200, { ok: true, real: true, auth: true, updated: db.meta?.updated });
    }

    // Protect mutating API (optional read without auth for static; write needs auth)
    const isApi = p.startsWith('/api/');
    const isAuthRoute = p.startsWith('/api/auth/');
    if (isApi && !isAuthRoute && req.method !== 'GET') {
      const s = requireAuth(req, res);
      if (!s) return;
    }
    // GET lists also require auth except health
    if (isApi && !isAuthRoute && req.method === 'GET' && p !== '/api/health') {
      const s = requireAuth(req, res);
      if (!s) return;
    }

    if (p === '/api/settings') {
      if (req.method === 'GET') return send(res, 200, db.settings || {});
      if (req.method === 'PUT') {
        const body = await readBody(req);
        db.settings = { ...(db.settings || {}), ...body };
        saveDb(db);
        return send(res, 200, db.settings);
      }
    }

    if (p === '/api/integrations') {
      if (req.method === 'GET') return send(res, 200, db.integrations || {});
      if (req.method === 'PUT') {
        db.integrations = await readBody(req);
        saveDb(db);
        return send(res, 200, db.integrations);
      }
    }

    if (p === '/api/warehouse') {
      if (req.method === 'GET') return send(res, 200, { warehouse: db.warehouse });
      if (req.method === 'PUT') {
        const body = await readBody(req);
        db.warehouse = body.warehouse || db.warehouse;
        saveDb(db);
        return send(res, 200, { warehouse: db.warehouse });
      }
    }

    if (p === '/api/backup' && req.method === 'GET') return send(res, 200, db);
    if (p === '/api/backup/restore' && req.method === 'POST') {
      const body = await readBody(req);
      if (!body.meta) return send(res, 400, { error: 'Invalid' });
      db = body; saveDb(db);
      return send(res, 200, { ok: true });
    }

    if (p === '/api/products/bulk' && req.method === 'PUT') {
      const body = await readBody(req);
      if (!Array.isArray(body)) return send(res, 400, { error: 'Array required' });
      db.products = body.map((x, i) => ({ ...x, id: x.id || i + 1 }));
      saveDb(db);
      return send(res, 200, { count: db.products.length });
    }

    for (const col of COLLECTIONS) {
      if (p === '/api/' + col) {
        if (req.method === 'GET') {
          let list = db[col] || [];
          if (col === 'users') list = list.map(publicUser);
          return send(res, 200, list);
        }
        if (req.method === 'POST') {
          if (col === 'users') {
            const s = requireAuth(req, res, true);
            if (!s) return;
          }
          const body = await readBody(req);
          const item = { ...body, id: nextId(db[col] || []) };
          if (col === 'users') {
            const pwd = body.password || 'user123';
            const h = hashPassword(pwd);
            item.salt = h.salt;
            item.passwordHash = h.hash;
            delete item.password;
          }
          db[col] = db[col] || [];
          db[col].push(item);
          saveDb(db);
          try { const sess = getSession(req); pushHistory(col, item.id, 'create', sess?.name, {}); } catch(e){}
          return send(res, 201, col === 'users' ? publicUser(item) : item);
        }
      }
      const m = p.match(new RegExp('^/api/' + col + '/(\\d+)$'));
      if (m) {
        const id = +m[1];
        if (req.method === 'PUT') {
          if (col === 'users') {
            const s = requireAuth(req, res, true);
            if (!s) return;
          }
          const body = await readBody(req);
          const i = (db[col] || []).findIndex(x => x.id === id);
          if (i < 0) return send(res, 404, { error: 'Not found' });
          const prev = db[col][i];
          const merged = { ...prev, ...body, id };
          if (col === 'users') {
            if (body.password) {
              const h = hashPassword(body.password);
              merged.salt = h.salt;
              merged.passwordHash = h.hash;
            }
            delete merged.password;
          }
          db[col][i] = merged;
          saveDb(db);
          try { const sess = getSession(req); pushHistory(col, id, 'update', sess?.name, { keys: Object.keys(body||{}) }); } catch(e){}
          return send(res, 200, col === 'users' ? publicUser(merged) : merged);
        }
        if (req.method === 'DELETE') {
          if (col === 'users') {
            const s = requireAuth(req, res, true);
            if (!s) return;
          }
          db[col] = (db[col] || []).filter(x => x.id !== id);
          saveDb(db);
          return send(res, 200, { ok: true });
        }
      }
    }

    // Static files (login page is part of index.html)
    let filePath = path.join(ROOT, p === '/' ? 'index.html' : decodeURIComponent(p));
    if (!filePath.startsWith(ROOT)) return send(res, 403, { error: 'Forbidden' });
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const data = fs.readFileSync(filePath);
      const headers = { 'Content-Type': mime(filePath), 'Access-Control-Allow-Origin': '*' };
      if (filePath.endsWith('.html')) headers['Cache-Control'] = 'no-store';
      else headers['Cache-Control'] = 'public, max-age=3600';
      res.writeHead(200, headers);
      return res.end(data);
    }
    send(res, 404, { error: 'Not found', path: p });
  } catch (e) {
    console.error(e);
    send(res, 500, { error: e.message });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  OfficePlus ERP — REAL + AUTH');
  console.log('  UI:   http://127.0.0.1:' + PORT + '/index.html');
  console.log('  API:  http://127.0.0.1:' + PORT + '/api/health');
  console.log('  User: admin / admin123');
  console.log('  User: sales01 / sales123');
  console.log('  DB:   ' + DB_FILE);
  console.log('');
});
