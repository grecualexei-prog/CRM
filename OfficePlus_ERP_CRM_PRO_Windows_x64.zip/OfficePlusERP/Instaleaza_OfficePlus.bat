@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
title OfficePlus ERP + CRM PRO - Instalare
color 0A
cls
echo.
echo  ========================================================
echo   OfficePlus ERP + CRM PRO
echo   Instalare Windows x64  (fara Inno Setup / ISS)
echo  ========================================================
echo.

set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\OfficePlusERP"

echo  [1/4] Creare folder destinatie...
if not exist "%DEST%" (
  mkdir "%DEST%" 2>nul
)
if not exist "%DEST%" (
  echo  EROARE: Nu pot crea folderul %DEST%
  echo  Ruleaza ca utilizator normal (nu e nevoie de Admin).
  pause
  exit /b 1
)
echo       OK: %DEST%

echo  [2/4] Copiere fisiere...
copy /Y "%SRC%index.html" "%DEST%\index.html" >nul
if errorlevel 1 (
  echo  EROARE la copierea index.html
  pause
  exit /b 1
)
copy /Y "%SRC%Lanseaza_OfficePlus.bat" "%DEST%\Lanseaza_OfficePlus.bat" >nul
copy /Y "%SRC%Dezinstaleaza.bat" "%DEST%\Dezinstaleaza.bat" >nul
if exist "%SRC%README.txt" copy /Y "%SRC%README.txt" "%DEST%\README.txt" >nul
echo       OK: fisiere copiate

echo  [3/4] Creare scurtaturi Desktop + Meniu Start...

:: Gaseste Desktop (inclusiv OneDrive)
set "DESKTOP=%USERPROFILE%\Desktop"
if not exist "%DESKTOP%" set "DESKTOP=%USERPROFILE%\OneDrive\Desktop"
if not exist "%DESKTOP%" set "DESKTOP=%USERPROFILE%\OneDrive\Desktopul"

:: Shortcut pe Desktop cu VBScript (functioneaza chiar daca PowerShell e blocat)
set "VBS=%TEMP%\op_shortcut.vbs"
(
  echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
  echo sLink = oWS.ExpandEnvironmentStrings^("%DESKTOP%\OfficePlus ERP.lnk"^)
  echo Set oLink = oWS.CreateShortcut^(sLink^)
  echo oLink.TargetPath = "%DEST%\Lanseaza_OfficePlus.bat"
  echo oLink.WorkingDirectory = "%DEST%"
  echo oLink.Description = "OfficePlus ERP + CRM PRO"
  echo oLink.WindowStyle = 1
  echo oLink.Save
) > "%VBS%"
cscript //nologo "%VBS%" >nul 2>&1
if exist "%DESKTOP%\OfficePlus ERP.lnk" (
  echo       OK: Desktop
) else (
  echo       ATENTIE: nu s-a putut crea scurtatura pe Desktop
)

:: Meniu Start
set "SM=%APPDATA%\Microsoft\Windows\Start Menu\Programs\OfficePlus"
if not exist "%SM%" mkdir "%SM%" 2>nul
(
  echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
  echo sLink = oWS.ExpandEnvironmentStrings^("%SM%\OfficePlus ERP.lnk"^)
  echo Set oLink = oWS.CreateShortcut^(sLink^)
  echo oLink.TargetPath = "%DEST%\Lanseaza_OfficePlus.bat"
  echo oLink.WorkingDirectory = "%DEST%"
  echo oLink.Description = "OfficePlus ERP + CRM PRO"
  echo oLink.Save
) > "%VBS%"
cscript //nologo "%VBS%" >nul 2>&1
del "%VBS%" >nul 2>&1
if exist "%SM%\OfficePlus ERP.lnk" (
  echo       OK: Meniu Start
) else (
  echo       ATENTIE: nu s-a putut crea scurtatura in Meniu Start
)

echo  [4/4] Verificare finala...
if exist "%DEST%\index.html" (
  echo.
  echo  ========================================================
  echo   INSTALARE FINALIZATA CU SUCCES
  echo  ========================================================
  echo.
  echo   Locatie:  %DEST%
  echo   Desktop:  OfficePlus ERP
  echo   Start:    OfficePlus \ OfficePlus ERP
  echo.
  echo   Se lanseaza aplicatia acum...
  echo.
  timeout /t 2 /nobreak >nul
  start "" "%DEST%\Lanseaza_OfficePlus.bat"
) else (
  echo  EROARE: Instalarea a esuat.
  pause
  exit /b 1
)

echo.
echo  Poti inchide aceasta fereastra.
timeout /t 4 /nobreak >nul
exit /b 0
