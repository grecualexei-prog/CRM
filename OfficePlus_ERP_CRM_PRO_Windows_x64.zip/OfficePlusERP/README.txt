OfficePlus ERP
==============

LOGIN (doar user + parolă)
  admin / admin123
  sales01 / sales123

GOOGLE DRIVE (stocare fișiere, nu login)
  1. Activează Google Drive API în Google Cloud
  2. Credentials → Client ID tip Web
  3. Redirect URI:
     http://127.0.0.1:3847/api/google/callback
  4. Setări → Google Drive API → Client ID + Secret
  5. Integrări → Conectează Google Drive
  6. Scanare → Salvează pe Google Drive

Folder Drive: OfficePlus_Scanate

PORNIRE: Lanseaza_OfficePlus.bat
