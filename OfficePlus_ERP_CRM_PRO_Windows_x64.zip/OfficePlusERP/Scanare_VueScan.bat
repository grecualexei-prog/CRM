@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "scanate" mkdir scanate
set "VS="
if exist "%ProgramFiles%\VueScan\vuescan.exe" set "VS=%ProgramFiles%\VueScan\vuescan.exe"
if exist "%ProgramFiles(x86)%\VueScan\vuescan.exe" set "VS=%ProgramFiles(x86)%\VueScan\vuescan.exe"
if exist "%ProgramFiles%\VueScan\vuescan64.exe" set "VS=%ProgramFiles%\VueScan\vuescan64.exe"
if defined VS (
  start "" "%VS%"
  explorer "%~dp0scanate"
  echo VueScan lansat. Salveaza scanarea in folderul scanate.
) else (
  echo VueScan nu a fost gasit.
  explorer "%~dp0scanate"
  pause
)
